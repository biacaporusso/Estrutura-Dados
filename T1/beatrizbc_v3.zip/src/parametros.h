#ifndef parametros_h
#define parametros_h

char* getNomeQry(char* arquivoQry);
void diretorios(char* diretorio, char* arquivoGeo, char* arqCompleto);

#endif